_base_ = [
    '../_base_/models/resnet18.py',
    '../_base_/datasets/mit_scene_bs8_448.py',
    '../_base_/schedules/cifar10_bs128.py', 
    '../_base_/default_runtime.py',
]

# model settings
# use pre-train weight converted from https://github.com/Alibaba-MIIL/ImageNet21K # noqa
# pretrained = 'https://download.openmmlab.com/mmclassification/v0/resnet/resnet50_3rdparty-mill_in21k_20220331-faac000b.pth'  # noqa

model = dict(
    type='ImageClassifier',
    head=dict(num_classes=67, ))
"""
backbone=dict(
    init_cfg=dict(
        type='Pretrained', checkpoint=pretrained, prefix='backbone')),
"""

# runtime settings
default_hooks = dict(logger=dict(type='LoggerHook', interval=20))

"""
optim_wrapper = dict(
    optimizer=dict(
        lr=0.01, momentum=0.9, nesterov=True, type='SGD', weight_decay=0.0005))
param_scheduler = [
    dict(
        begin=0,
        by_epoch=True,
        convert_to_iter_based=True,
        end=5,
        start_factor=0.01,
        type='LinearLR'),
    dict(T_max=95, begin=5, by_epoch=True, end=100, type='CosineAnnealingLR'),
]
"""
