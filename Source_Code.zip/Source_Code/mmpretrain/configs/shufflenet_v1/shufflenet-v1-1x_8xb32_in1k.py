_base_ = [
    '../_base_/models/shufflenet_v1_1x.py', '../_base_/datasets/imagenet_bs32.py',
    '../_base_/schedules/imagenet_bs256.py', '../_base_/default_runtime.py'
]

# optimizer
optim_wrapper = dict(
    optimizer=dict(type='SGD', lr=0.1, momentum=0.9, weight_decay=0.0001))

# learning policy
"""
param_scheduler = dict(
    type='MultiStepLR', by_epoch=True, milestones=[40, 70, 120], gamma=0.1)
"""
param_scheduler = dict(
    type='MultiStepLR', by_epoch=True, milestones=[30, 60, 90], gamma=0.1)

# train, val, test setting
train_cfg = dict(by_epoch=True, max_epochs=110, val_interval=1)

