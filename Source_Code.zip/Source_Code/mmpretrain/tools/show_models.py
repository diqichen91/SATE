from mmpretrain import ImageClassificationInferencer
import pdb

# config = 'configs/resnet/resnet50_8xb16_cifar100.py'
# config = 'configs/resnet/resnet18_8xb16_cifar100.py'
# config = 'configs/resnet/resnet32x4_8xb16_cifar100.py'
# config = 'configs/resnet/resnet8x4_8xb16_cifar100.py'
# config = 'configs/wrn/wrn40-2_8xb16_cifar100.py'
# config = 'configs/wrn/wrn16-2_8xb16_cifar100.py'
# config = 'configs/mobilenet_v2/mobilenet-v2_8xb16_cifar100.py'
config = 'configs/shufflenet_v1/shufflenet-v1-1x_8xb16_cifar100.py'
# config = 'configs/shufflenet_v2/shufflenet-v2-1x_8xb16_cifar100.py'

inferencer = ImageClassificationInferencer(model=config, pretrained=False)
print(inferencer.model)

pdb.set_trace()


"""
Model Size
!!!Only the backbone network is counted in FLOPs analysis.

Input shape: (3, 32, 32)

python tools/analysis_tools/get_flops.py configs/resnet/resnet50_8xb16_cifar100.py --shape 32
resnet50:
+--------------------------+----------------------+------------+--------------+
| module                   | #parameters or shape | #flops     | #activations |
+--------------------------+----------------------+------------+--------------+
| model                    | 23.705M              | 1.305G     | 3.432M       |
|  backbone                |  23.5M               |  1.305G    |  3.432M      |
|   backbone.conv1         |   1.728K             |   1.769M   |   65.536K    |
|    backbone.conv1.weight |    (64, 3, 3, 3)     |            |              |
|   backbone.bn1           |   0.128K             |   0.131M   |   0          |
|    backbone.bn1.weight   |    (64,)             |            |              |
|    backbone.bn1.bias     |    (64,)             |            |              |
|   backbone.layer1        |   0.216M             |   0.221G   |   1.442M     |
|    backbone.layer1.0     |    75.008K           |    76.808M |    0.655M    |
|    backbone.layer1.1     |    70.4K             |    72.09M  |    0.393M    |
|    backbone.layer1.2     |    70.4K             |    72.09M  |    0.393M    |
|   backbone.layer2        |   1.22M              |   0.338G   |   1.016M     |
|    backbone.layer2.0     |    0.379M            |    0.122G  |    0.426M    |
|    backbone.layer2.1     |    0.28M             |    71.696M |    0.197M    |
|    backbone.layer2.2     |    0.28M             |    71.696M |    0.197M    |
|    backbone.layer2.3     |    0.28M             |    71.696M |    0.197M    |
|   backbone.layer3        |   7.098M             |   0.48G    |   0.705M     |
|    backbone.layer3.0     |    1.512M            |    0.122G  |    0.213M    |
|    backbone.layer3.1     |    1.117M            |    71.5M   |    98.304K   |
|    backbone.layer3.2     |    1.117M            |    71.5M   |    98.304K   |
|    backbone.layer3.3     |    1.117M            |    71.5M   |    98.304K   |
|    backbone.layer3.4     |    1.117M            |    71.5M   |    98.304K   |
|    backbone.layer3.5     |    1.117M            |    71.5M   |    98.304K   |
|   backbone.layer4        |   14.965M            |   0.265G   |   0.205M     |
|    backbone.layer4.0     |    6.04M             |    0.122G  |    0.106M    |
|    backbone.layer4.1     |    4.463M            |    71.401M |    49.152K   |
|    backbone.layer4.2     |    4.463M            |    71.401M |    49.152K   |
|  head.fc                 |  0.205M              |            |              |
|   head.fc.weight         |   (100, 2048)        |            |              |
|   head.fc.bias           |   (100,)             |            |              |
|  neck.gap                |                      |  32.768K   |  0           |
+--------------------------+----------------------+------------+--------------+
Flops: 1.305G
Params: 23.705M
Activation: 3.432M

python tools/analysis_tools/get_flops.py configs/resnet/resnet18_8xb16_cifar100.py --shape 32
resnet18:
+--------------------------+----------------------+------------+--------------+
| module                   | #parameters or shape | #flops     | #activations |
+--------------------------+----------------------+------------+--------------+
| model                    | 11.22M               | 0.557G     | 0.614M       |
|  backbone                |  11.169M             |  0.557G    |  0.614M      |
|   backbone.conv1         |   1.728K             |   1.769M   |   65.536K    |
|    backbone.conv1.weight |    (64, 3, 3, 3)     |            |              |
|   backbone.bn1           |   0.128K             |   0.131M   |   0          |
|    backbone.bn1.weight   |    (64,)             |            |              |
|    backbone.bn1.bias     |    (64,)             |            |              |
|   backbone.layer1        |   0.148M             |   0.152G   |   0.262M     |
|    backbone.layer1.0     |    73.984K           |    75.76M  |    0.131M    |
|    backbone.layer1.1     |    73.984K           |    75.76M  |    0.131M    |
|   backbone.layer2        |   0.526M             |   0.135G   |   0.164M     |
|    backbone.layer2.0     |    0.23M             |    58.917M |    98.304K   |
|    backbone.layer2.1     |    0.295M            |    75.629M |    65.536K   |
|   backbone.layer3        |   2.1M               |   0.134G   |   81.92K     |
|    backbone.layer3.0     |    0.919M            |    58.819M |    49.152K   |
|    backbone.layer3.1     |    1.181M            |    75.563M |    32.768K   |
|   backbone.layer4        |   8.394M             |   0.134G   |   40.96K     |
|    backbone.layer4.0     |    3.673M            |    58.769M |    24.576K   |
|    backbone.layer4.1     |    4.721M            |    75.53M  |    16.384K   |
|  head.fc                 |  51.3K               |            |              |
|   head.fc.weight         |   (100, 512)         |            |              |
|   head.fc.bias           |   (100,)             |            |              |
|  neck.gap                |                      |  8.192K    |  0           |
+--------------------------+----------------------+------------+--------------+
Flops: 0.557G
Params: 11.22M
Activation: 0.614M

python tools/analysis_tools/get_flops.py configs/resnet/resnet32x4_8xb16_cifar100.py --shape 32
resnet32x4:
+--------------------------+----------------------+------------+--------------+
| module                   | #parameters or shape | #flops     | #activations |
+--------------------------+----------------------+------------+--------------+
| model                    | 7.434M               | 1.086G     | 1.294M       |
|  backbone                |  7.408M              |  1.086G    |  1.294M      |
|   backbone.conv1         |   0.864K             |   0.885M   |   32.768K    |
|    backbone.conv1.weight |    (32, 3, 3, 3)     |            |              |
|   backbone.bn1           |   64                 |   65.536K  |   0          |
|    backbone.bn1.weight   |    (32,)             |            |              |
|    backbone.bn1.bias     |    (32,)             |            |              |
|   backbone.layer1        |   0.354M             |   0.362G   |   0.721M     |
|    backbone.layer1.0     |    57.728K           |    59.113M |    0.197M    |
|    backbone.layer1.1     |    73.984K           |    75.76M  |    0.131M    |
|    backbone.layer1.2     |    73.984K           |    75.76M  |    0.131M    |
|    backbone.layer1.3     |    73.984K           |    75.76M  |    0.131M    |
|    backbone.layer1.4     |    73.984K           |    75.76M  |    0.131M    |
|   backbone.layer2        |   1.412M             |   0.361G   |   0.36M      |
|    backbone.layer2.0     |    0.23M             |    58.917M |    98.304K   |
|    backbone.layer2.1     |    0.295M            |    75.629M |    65.536K   |
|    backbone.layer2.2     |    0.295M            |    75.629M |    65.536K   |
|    backbone.layer2.3     |    0.295M            |    75.629M |    65.536K   |
|    backbone.layer2.4     |    0.295M            |    75.629M |    65.536K   |
|   backbone.layer3        |   5.642M             |   0.361G   |   0.18M      |
|    backbone.layer3.0     |    0.919M            |    58.819M |    49.152K   |
|    backbone.layer3.1     |    1.181M            |    75.563M |    32.768K   |
|    backbone.layer3.2     |    1.181M            |    75.563M |    32.768K   |
|    backbone.layer3.3     |    1.181M            |    75.563M |    32.768K   |
|    backbone.layer3.4     |    1.181M            |    75.563M |    32.768K   |
|  head.fc                 |  25.7K               |            |              |
|   head.fc.weight         |   (100, 256)         |            |              |
|   head.fc.bias           |   (100,)             |            |              |
|  neck.gap                |                      |  16.384K   |  0           |
+--------------------------+----------------------+------------+--------------+
Flops: 1.086G
Params: 7.434M
Activation: 1.294M

python tools/analysis_tools/get_flops.py configs/resnet/resnet8x4_8xb16_cifar100.py --shape 32
resnet8x4:
+---------------------------------+----------------------+------------+--------------+
| module                          | #parameters or shape | #flops     | #activations |
+---------------------------------+----------------------+------------+--------------+
| model                           | 1.234M               | 0.178G     | 0.377M       |
|  backbone                       |  1.208M              |  0.178G    |  0.377M      |
|   backbone.conv1                |   0.864K             |   0.885M   |   32.768K    |
|    backbone.conv1.weight        |    (32, 3, 3, 3)     |            |              |
|   backbone.bn1                  |   64                 |   65.536K  |   0          |
|    backbone.bn1.weight          |    (32,)             |            |              |
|    backbone.bn1.bias            |    (32,)             |            |              |
|   backbone.layer1.0             |   57.728K            |   59.113M  |   0.197M     |
|    backbone.layer1.0.conv1      |    18.432K           |    18.874M |    65.536K   |
|    backbone.layer1.0.bn1        |    0.128K            |    0.131M  |    0         |
|    backbone.layer1.0.conv2      |    36.864K           |    37.749M |    65.536K   |
|    backbone.layer1.0.bn2        |    0.128K            |    0.131M  |    0         |
|    backbone.layer1.0.downsample |    2.176K            |    2.228M  |    65.536K   |
|   backbone.layer2.0             |   0.23M              |   58.917M  |   98.304K    |
|    backbone.layer2.0.conv1      |    73.728K           |    18.874M |    32.768K   |
|    backbone.layer2.0.bn1        |    0.256K            |    65.536K |    0         |
|    backbone.layer2.0.conv2      |    0.147M            |    37.749M |    32.768K   |
|    backbone.layer2.0.bn2        |    0.256K            |    65.536K |    0         |
|    backbone.layer2.0.downsample |    8.448K            |    2.163M  |    32.768K   |
|   backbone.layer3.0             |   0.919M             |   58.819M  |   49.152K    |
|    backbone.layer3.0.conv1      |    0.295M            |    18.874M |    16.384K   |
|    backbone.layer3.0.bn1        |    0.512K            |    32.768K |    0         |
|    backbone.layer3.0.conv2      |    0.59M             |    37.749M |    16.384K   |
|    backbone.layer3.0.bn2        |    0.512K            |    32.768K |    0         |
|    backbone.layer3.0.downsample |    33.28K            |    2.13M   |    16.384K   |
|  head.fc                        |  25.7K               |            |              |
|   head.fc.weight                |   (100, 256)         |            |              |
|   head.fc.bias                  |   (100,)             |            |              |
|  neck.gap                       |                      |  16.384K   |  0           |
+---------------------------------+----------------------+------------+--------------+
Flops: 0.178G
Params: 1.234M
Activation: 0.377M

python tools/analysis_tools/get_flops.py configs/wrn/wrn40-2_8xb16_cifar100.py --shape 32
wrn40-2:
+--------------------------+----------------------+------------+--------------+
| module                   | #parameters or shape | #flops     | #activations |
+--------------------------+----------------------+------------+--------------+
| model                    | 2.256M               | 0.329G     | 0.762M       |
|  backbone                |  2.243M              |  0.329G    |  0.762M      |
|   backbone.conv1         |   0.432K             |   0.442M   |   16.384K    |
|    backbone.conv1.weight |    (16, 3, 3, 3)     |            |              |
|   backbone.bn1           |   32                 |   32.768K  |   0          |
|    backbone.bn1.weight   |    (16,)             |            |              |
|    backbone.bn1.bias     |    (16,)             |            |              |
|   backbone.layer1        |   0.107M             |   0.11G    |   0.426M     |
|    backbone.layer1.0     |    14.528K           |    14.877M |    98.304K   |
|    backbone.layer1.1     |    18.56K            |    19.005M |    65.536K   |
|    backbone.layer1.2     |    18.56K            |    19.005M |    65.536K   |
|    backbone.layer1.3     |    18.56K            |    19.005M |    65.536K   |
|    backbone.layer1.4     |    18.56K            |    19.005M |    65.536K   |
|    backbone.layer1.5     |    18.56K            |    19.005M |    65.536K   |
|   backbone.layer2        |   0.428M             |   0.109G   |   0.213M     |
|    backbone.layer2.0     |    57.728K           |    14.778M |    49.152K   |
|    backbone.layer2.1     |    73.984K           |    18.94M  |    32.768K   |
|    backbone.layer2.2     |    73.984K           |    18.94M  |    32.768K   |
|    backbone.layer2.3     |    73.984K           |    18.94M  |    32.768K   |
|    backbone.layer2.4     |    73.984K           |    18.94M  |    32.768K   |
|    backbone.layer2.5     |    73.984K           |    18.94M  |    32.768K   |
|   backbone.layer3        |   1.707M             |   0.109G   |   0.106M     |
|    backbone.layer3.0     |    0.23M             |    14.729M |    24.576K   |
|    backbone.layer3.1     |    0.295M            |    18.907M |    16.384K   |
|    backbone.layer3.2     |    0.295M            |    18.907M |    16.384K   |
|    backbone.layer3.3     |    0.295M            |    18.907M |    16.384K   |
|    backbone.layer3.4     |    0.295M            |    18.907M |    16.384K   |
|    backbone.layer3.5     |    0.295M            |    18.907M |    16.384K   |
|  head.fc                 |  12.9K               |            |              |
|   head.fc.weight         |   (100, 128)         |            |              |
|   head.fc.bias           |   (100,)             |            |              |
|  neck.gap                |                      |  8.192K    |  0           |
+--------------------------+----------------------+------------+--------------+
Flops: 0.329G
Params: 2.256M
Activation: 0.762M

python tools/analysis_tools/get_flops.py configs/wrn/wrn16-2_8xb16_cifar100.py --shape 32
wrn16-2:
+--------------------------+----------------------+------------+--------------+
| module                   | #parameters or shape | #flops     | #activations |
+--------------------------+----------------------+------------+--------------+
| model                    | 0.704M               | 0.102G     | 0.303M       |
|  backbone                |  0.691M              |  0.102G    |  0.303M      |
|   backbone.conv1         |   0.432K             |   0.442M   |   16.384K    |
|    backbone.conv1.weight |    (16, 3, 3, 3)     |            |              |
|   backbone.bn1           |   32                 |   32.768K  |   0          |
|    backbone.bn1.weight   |    (16,)             |            |              |
|    backbone.bn1.bias     |    (16,)             |            |              |
|   backbone.layer1        |   33.088K            |   33.882M  |   0.164M     |
|    backbone.layer1.0     |    14.528K           |    14.877M |    98.304K   |
|    backbone.layer1.1     |    18.56K            |    19.005M |    65.536K   |
|   backbone.layer2        |   0.132M             |   33.718M  |   81.92K     |
|    backbone.layer2.0     |    57.728K           |    14.778M |    49.152K   |
|    backbone.layer2.1     |    73.984K           |    18.94M  |    32.768K   |
|   backbone.layer3        |   0.526M             |   33.636M  |   40.96K     |
|    backbone.layer3.0     |    0.23M             |    14.729M |    24.576K   |
|    backbone.layer3.1     |    0.295M            |    18.907M |    16.384K   |
|  head.fc                 |  12.9K               |            |              |
|   head.fc.weight         |   (100, 128)         |            |              |
|   head.fc.bias           |   (100,)             |            |              |
|  neck.gap                |                      |  8.192K    |  0           |
+--------------------------+----------------------+------------+--------------+
Flops: 0.102G
Params: 0.704M
Activation: 0.303M

python tools/analysis_tools/get_flops.py configs/mobilenet_v2/mobilenet-v2_8xb16_cifar100.py --shape 32
mobilenet-v2:
+-----------------------------+----------------------+------------+--------------+
| module                      | #parameters or shape | #flops     | #activations |
+-----------------------------+----------------------+------------+--------------+
| model                       | 2.352M               | 6.386M     | 0.136M       |
|  backbone                   |  2.224M              |  6.385M    |  0.136M      |
|   backbone.conv1            |   0.928K             |   0.238M   |   8.192K     |
|    backbone.conv1.conv      |    0.864K            |    0.221M  |    8.192K    |
|    backbone.conv1.bn        |    64                |    16.384K |    0         |
|   backbone.layer1.0.conv    |   0.896K             |   0.229M   |   12.288K    |
|    backbone.layer1.0.conv.0 |    0.352K            |    90.112K |    8.192K    |
|    backbone.layer1.0.conv.1 |    0.544K            |    0.139M  |    4.096K    |
|   backbone.layer2           |   13.968K            |   1.226M   |   52.224K    |
|    backbone.layer2.0.conv   |    5.136K            |    0.66M   |    32.256K   |
|    backbone.layer2.1.conv   |    8.832K            |    0.565M  |    19.968K   |
|   backbone.layer3           |   39.696K            |   0.815M   |   25.344K    |
|    backbone.layer3.0.conv   |    10K               |    0.34M   |    12.032K   |
|    backbone.layer3.1.conv   |    14.848K           |    0.238M  |    6.656K    |
|    backbone.layer3.2.conv   |    14.848K           |    0.238M  |    6.656K    |
|   backbone.layer4           |   0.184M             |   0.814M   |   14.08K     |
|    backbone.layer4.0.conv   |    21.056K           |    0.163M  |    4.096K    |
|    backbone.layer4.1.conv   |    54.272K           |    0.217M  |    3.328K    |
|    backbone.layer4.2.conv   |    54.272K           |    0.217M  |    3.328K    |
|    backbone.layer4.3.conv   |    54.272K           |    0.217M  |    3.328K    |
|   backbone.layer5           |   0.303M             |   1.213M   |   13.44K     |
|    backbone.layer5.0.conv   |    66.624K           |    0.266M  |    3.456K    |
|    backbone.layer5.1.conv   |    0.118M            |    0.473M  |    4.992K    |
|    backbone.layer5.2.conv   |    0.118M            |    0.473M  |    4.992K    |
|   backbone.layer6           |   0.795M             |   0.965M   |   7.2K       |
|    backbone.layer6.0.conv   |    0.155M            |    0.325M  |    3.04K     |
|    backbone.layer6.1.conv   |    0.32M             |    0.32M   |    2.08K     |
|    backbone.layer6.2.conv   |    0.32M             |    0.32M   |    2.08K     |
|   backbone.layer7.0.conv    |   0.474M             |   0.474M   |   2.24K      |
|    backbone.layer7.0.conv.0 |    0.156M            |    0.156M  |    0.96K     |
|    backbone.layer7.0.conv.1 |    10.56K            |    10.56K  |    0.96K     |
|    backbone.layer7.0.conv.2 |    0.308M            |    0.308M  |    0.32K     |
|   backbone.conv2            |   0.412M             |   0.412M   |   1.28K      |
|    backbone.conv2.conv      |    0.41M             |    0.41M   |    1.28K     |
|    backbone.conv2.bn        |    2.56K             |    2.56K   |    0         |
|  head.fc                    |  0.128M              |            |              |
|   head.fc.weight            |   (100, 1280)        |            |              |
|   head.fc.bias              |   (100,)             |            |              |
|  neck.gap                   |                      |  1.28K     |  0           |
+-----------------------------+----------------------+------------+--------------+
Flops: 6.386M
Params: 2.352M - 0.128M = 2.224M
Activation: 0.136M

python tools/analysis_tools/get_flops.py configs/shufflenet_v1/shufflenet-v1-1x_8xb16_cifar100.py --shape 32
shufflenet-v1:
+------------------------+----------------------+------------+--------------+
| module                 | #parameters or shape | #flops     | #activations |
+------------------------+----------------------+------------+--------------+
| model                  | 1.001M               | 2.909M     | 61.2K        |
|  backbone              |  0.905M              |  2.908M    |  61.2K       |
|   backbone.conv1       |   0.696K             |   0.178M   |   6.144K     |
|    backbone.conv1.conv |    0.648K            |    0.166M  |    6.144K    |
|    backbone.conv1.bn   |    48                |    12.288K |    0         |
|   backbone.layers      |   0.904M             |   2.73M    |   55.056K    |
|    backbone.layers.0   |    39.552K           |    0.708M  |    25.536K   |
|    backbone.layers.1   |    0.308M            |    1.349M  |    23.52K    |
|    backbone.layers.2   |    0.557M            |    0.673M  |    6K        |
|  head.fc               |  96.1K               |            |              |
|   head.fc.weight       |   (100, 960)         |            |              |
|   head.fc.bias         |   (100,)             |            |              |
|  neck.gap              |                      |  0.96K     |  0           |
+------------------------+----------------------+------------+--------------+
Flops: 2.909M
Params: 1.001M
Activation: 61.2K

python tools/analysis_tools/get_flops.py configs/shufflenet_v2/shufflenet-v2-1x_8xb16_cifar100.py --shape 32
shufflenet-v2:
+------------------------+----------------------+------------+--------------+
| module                 | #parameters or shape | #flops     | #activations |
+------------------------+----------------------+------------+--------------+
| model                  | 1.356M               | 3.017M     | 39.8K        |
|  backbone              |  1.254M              |  3.016M    |  39.8K       |
|   backbone.conv1       |   0.696K             |   0.178M   |   6.144K     |
|    backbone.conv1.conv |    0.648K            |    0.166M  |    6.144K    |
|    backbone.conv1.bn   |    48                |    12.288K |    0         |
|   backbone.layers      |   1.253M             |   2.838M   |   33.656K    |
|    backbone.layers.0   |    30.192K           |    0.555M  |    15.232K   |
|    backbone.layers.1   |    0.244M            |    1.141M  |    13.456K   |
|    backbone.layers.2   |    0.501M            |    0.664M  |    3.944K    |
|    backbone.layers.3   |    0.477M            |    0.477M  |    1.024K    |
|  head.fc               |  0.102M              |            |              |
|   head.fc.weight       |   (100, 1024)        |            |              |
|   head.fc.bias         |   (100,)             |            |              |
|  neck.gap              |                      |  1.024K    |  0           |
+------------------------+----------------------+------------+--------------+
Flops: 3.017M
Params: 1.356M - 0.102M = 1.254M
Activation: 39.8K
"""

"""
Model Structure:

resnet50:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): ResNet_CIFAR(
    (conv1): Conv2d(3, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
    (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
    (relu): ReLU(inplace=True)
    (layer1): ResLayer(
      (0): Bottleneck(
        (conv1): Conv2d(64, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(64, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(64, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
          (1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): Bottleneck(
        (conv1): Conv2d(256, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(64, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): Bottleneck(
        (conv1): Conv2d(256, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(64, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer2): ResLayer(
      (0): Bottleneck(
        (conv1): Conv2d(256, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(128, 512, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(256, 512, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): Bottleneck(
        (conv1): Conv2d(512, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(128, 512, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): Bottleneck(
        (conv1): Conv2d(512, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(128, 512, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (3): Bottleneck(
        (conv1): Conv2d(512, 128, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(128, 512, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer3): ResLayer(
      (0): Bottleneck(
        (conv1): Conv2d(512, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(256, 1024, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(512, 1024, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): Bottleneck(
        (conv1): Conv2d(1024, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(256, 1024, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): Bottleneck(
        (conv1): Conv2d(1024, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(256, 1024, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (3): Bottleneck(
        (conv1): Conv2d(1024, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(256, 1024, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (4): Bottleneck(
        (conv1): Conv2d(1024, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(256, 1024, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (5): Bottleneck(
        (conv1): Conv2d(1024, 256, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(256, 1024, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer4): ResLayer(
      (0): Bottleneck(
        (conv1): Conv2d(1024, 512, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(512, 512, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(512, 2048, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(2048, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(1024, 2048, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(2048, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): Bottleneck(
        (conv1): Conv2d(2048, 512, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(512, 512, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(512, 2048, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(2048, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): Bottleneck(
        (conv1): Conv2d(2048, 512, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(512, 512, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv3): Conv2d(512, 2048, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn3): BatchNorm2d(2048, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
  )
  init_cfg=[{'type': 'Kaiming', 'layer': ['Conv2d']}, {'type': 'Constant', 'val': 1, 'layer': ['_BatchNorm', 'GroupNorm']}]
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=2048, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)

resnet18:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): ResNet_CIFAR(
    (conv1): Conv2d(3, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
    (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
    (relu): ReLU(inplace=True)
    (layer1): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer2): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(64, 128, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(64, 128, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer3): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(128, 256, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(128, 256, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer4): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(256, 512, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(512, 512, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(256, 512, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(512, 512, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(512, 512, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
  )
  init_cfg=[{'type': 'Kaiming', 'layer': ['Conv2d']}, {'type': 'Constant', 'val': 1, 'layer': ['_BatchNorm', 'GroupNorm']}]
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=512, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)

resnet32x4:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): ResNet_CIFAR(
    (conv1): Conv2d(3, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
    (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
    (relu): ReLU(inplace=True)
    (layer1): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(32, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(32, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
          (1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (3): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (4): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer2): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(64, 128, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(64, 128, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (3): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (4): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer3): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(128, 256, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(128, 256, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): BasicBlock(
        (conv1): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (3): BasicBlock(
        (conv1): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (4): BasicBlock(
        (conv1): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
  )
  init_cfg=[{'type': 'Kaiming', 'layer': ['Conv2d']}, {'type': 'Constant', 'val': 1, 'layer': ['_BatchNorm', 'GroupNorm']}]
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=256, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)

resnet8x4:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): ResNet_CIFAR(
    (conv1): Conv2d(3, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
    (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
    (relu): ReLU(inplace=True)
    (layer1): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(32, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(32, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
          (1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
    )
    (layer2): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(64, 128, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(64, 128, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
    )
    (layer3): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(128, 256, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(256, 256, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(128, 256, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
    )
  )
  init_cfg=[{'type': 'Kaiming', 'layer': ['Conv2d']}, {'type': 'Constant', 'val': 1, 'layer': ['_BatchNorm', 'GroupNorm']}]
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=256, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)

wrn40-2:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): ResNet_CIFAR(
    (conv1): Conv2d(3, 16, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
    (bn1): BatchNorm2d(16, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
    (relu): ReLU(inplace=True)
    (layer1): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(16, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(16, 32, kernel_size=(1, 1), stride=(1, 1), bias=False)
          (1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): BasicBlock(
        (conv1): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (3): BasicBlock(
        (conv1): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (4): BasicBlock(
        (conv1): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (5): BasicBlock(
        (conv1): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer2): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(32, 64, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(32, 64, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (3): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (4): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (5): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer3): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(64, 128, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(64, 128, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (2): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (3): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (4): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
      (5): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
  )
  init_cfg=[{'type': 'Kaiming', 'layer': ['Conv2d']}, {'type': 'Constant', 'val': 1, 'layer': ['_BatchNorm', 'GroupNorm']}]
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=128, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)

wrn16-2:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): ResNet_CIFAR(
    (conv1): Conv2d(3, 16, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
    (bn1): BatchNorm2d(16, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
    (relu): ReLU(inplace=True)
    (layer1): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(16, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(16, 32, kernel_size=(1, 1), stride=(1, 1), bias=False)
          (1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer2): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(32, 64, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(32, 64, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(64, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
    (layer3): ResLayer(
      (0): BasicBlock(
        (conv1): Conv2d(64, 128, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (downsample): Sequential(
          (0): Conv2d(64, 128, kernel_size=(1, 1), stride=(2, 2), bias=False)
          (1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        (drop_path): Identity()
      )
      (1): BasicBlock(
        (conv1): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn1): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (conv2): Conv2d(128, 128, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        (bn2): BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (relu): ReLU(inplace=True)
        (drop_path): Identity()
      )
    )
  )
  init_cfg=[{'type': 'Kaiming', 'layer': ['Conv2d']}, {'type': 'Constant', 'val': 1, 'layer': ['_BatchNorm', 'GroupNorm']}]
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=128, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)

mobilenet-v2:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): MobileNetV2(
    (conv1): ConvModule(
      (conv): Conv2d(3, 32, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
      (bn): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (activate): ReLU6(inplace=True)
    )
    (layer1): Sequential(
      (0): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=32, bias=False)
            (bn): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(32, 16, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(16, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
    )
    (layer2): Sequential(
      (0): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(16, 96, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(96, 96, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=96, bias=False)
            (bn): BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(96, 24, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(24, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (1): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(24, 144, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(144, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(144, 144, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=144, bias=False)
            (bn): BatchNorm2d(144, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(144, 24, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(24, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
    )
    (layer3): Sequential(
      (0): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(24, 144, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(144, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(144, 144, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=144, bias=False)
            (bn): BatchNorm2d(144, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(144, 32, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (1): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(32, 192, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(192, 192, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=192, bias=False)
            (bn): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(192, 32, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (2): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(32, 192, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(192, 192, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=192, bias=False)
            (bn): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(192, 32, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
    )
    (layer4): Sequential(
      (0): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(32, 192, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(192, 192, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=192, bias=False)
            (bn): BatchNorm2d(192, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(192, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (1): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(64, 384, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(384, 384, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=384, bias=False)
            (bn): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(384, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (2): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(64, 384, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(384, 384, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=384, bias=False)
            (bn): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(384, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (3): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(64, 384, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(384, 384, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=384, bias=False)
            (bn): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(384, 64, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(64, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
    )
    (layer5): Sequential(
      (0): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(64, 384, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(384, 384, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=384, bias=False)
            (bn): BatchNorm2d(384, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(384, 96, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (1): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(96, 576, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(576, 576, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=576, bias=False)
            (bn): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(576, 96, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (2): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(96, 576, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(576, 576, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=576, bias=False)
            (bn): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(576, 96, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
    )
    (layer6): Sequential(
      (0): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(96, 576, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(576, 576, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=576, bias=False)
            (bn): BatchNorm2d(576, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(576, 160, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (1): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(160, 960, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(960, 960, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=960, bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(960, 160, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
      (2): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(160, 960, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(960, 960, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=960, bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(960, 160, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(160, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
    )
    (layer7): Sequential(
      (0): InvertedResidual(
        (conv): Sequential(
          (0): ConvModule(
            (conv): Conv2d(160, 960, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (1): ConvModule(
            (conv): Conv2d(960, 960, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=960, bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU6(inplace=True)
          )
          (2): ConvModule(
            (conv): Conv2d(960, 320, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(320, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
        )
      )
    )
    (conv2): ConvModule(
      (conv): Conv2d(320, 1280, kernel_size=(1, 1), stride=(1, 1), bias=False)
      (bn): BatchNorm2d(1280, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (activate): ReLU6(inplace=True)
    )
  )
  init_cfg=[{'type': 'Kaiming', 'layer': ['Conv2d']}, {'type': 'Constant', 'val': 1, 'layer': ['_BatchNorm', 'GroupNorm']}]
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=1280, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)

shufflenet-v1:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): ShuffleNetV1(
    (conv1): ConvModule(
      (conv): Conv2d(3, 24, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
      (bn): BatchNorm2d(24, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (activate): ReLU(inplace=True)
    )
    (maxpool): MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)
    (layers): ModuleList(
      (0): Sequential(
        (0): ShuffleUnit(
          (avgpool): AvgPool2d(kernel_size=3, stride=2, padding=1)
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(24, 60, kernel_size=(1, 1), stride=(1, 1), bias=False)
            (bn): BatchNorm2d(60, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(60, 60, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=60, bias=False)
            (bn): BatchNorm2d(60, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(60, 216, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(216, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (1): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(240, 60, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(60, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(60, 60, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=60, bias=False)
            (bn): BatchNorm2d(60, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(60, 240, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (2): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(240, 60, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(60, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(60, 60, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=60, bias=False)
            (bn): BatchNorm2d(60, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(60, 240, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (3): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(240, 60, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(60, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(60, 60, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=60, bias=False)
            (bn): BatchNorm2d(60, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(60, 240, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
      )
      (1): Sequential(
        (0): ShuffleUnit(
          (avgpool): AvgPool2d(kernel_size=3, stride=2, padding=1)
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(240, 120, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(120, 120, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=120, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(120, 240, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (1): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(480, 120, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(120, 120, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=120, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(120, 480, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (2): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(480, 120, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(120, 120, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=120, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(120, 480, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (3): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(480, 120, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(120, 120, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=120, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(120, 480, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (4): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(480, 120, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(120, 120, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=120, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(120, 480, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (5): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(480, 120, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(120, 120, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=120, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(120, 480, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (6): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(480, 120, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(120, 120, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=120, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(120, 480, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (7): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(480, 120, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(120, 120, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=120, bias=False)
            (bn): BatchNorm2d(120, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(120, 480, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
      )
      (2): Sequential(
        (0): ShuffleUnit(
          (avgpool): AvgPool2d(kernel_size=3, stride=2, padding=1)
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(480, 240, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(240, 240, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=240, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(240, 480, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(480, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (1): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(960, 240, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(240, 240, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=240, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(240, 960, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (2): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(960, 240, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(240, 240, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=240, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(240, 960, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
        (3): ShuffleUnit(
          (g_conv_1x1_compress): ConvModule(
            (conv): Conv2d(960, 240, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            (activate): ReLU(inplace=True)
          )
          (depthwise_conv3x3_bn): ConvModule(
            (conv): Conv2d(240, 240, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=240, bias=False)
            (bn): BatchNorm2d(240, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (g_conv_1x1_expand): ConvModule(
            (conv): Conv2d(240, 960, kernel_size=(1, 1), stride=(1, 1), groups=3, bias=False)
            (bn): BatchNorm2d(960, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
          )
          (act): ReLU()
        )
      )
    )
  )
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=960, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)

shufflenet-v2:
ImageClassifier(
  (data_preprocessor): ClsDataPreprocessor()
  (backbone): ShuffleNetV2(
    (conv1): ConvModule(
      (conv): Conv2d(3, 24, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False)
      (bn): BatchNorm2d(24, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
      (activate): ReLU(inplace=True)
    )
    (maxpool): MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)
    (layers): ModuleList(
      (0): Sequential(
        (0): InvertedResidual(
          (branch1): Sequential(
            (0): ConvModule(
              (conv): Conv2d(24, 24, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=24, bias=False)
              (bn): BatchNorm2d(24, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (1): ConvModule(
              (conv): Conv2d(24, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(24, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=58, bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (1): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=58, bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (2): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=58, bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (3): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=58, bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(58, 58, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(58, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
      )
      (1): Sequential(
        (0): InvertedResidual(
          (branch1): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (1): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (2): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (3): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (4): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (5): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (6): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (7): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=116, bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(116, 116, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(116, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
      )
      (2): Sequential(
        (0): InvertedResidual(
          (branch1): Sequential(
            (0): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=232, bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (1): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), groups=232, bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (1): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=232, bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (2): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=232, bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
        (3): InvertedResidual(
          (branch2): Sequential(
            (0): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
            (1): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=232, bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )
            (2): ConvModule(
              (conv): Conv2d(232, 232, kernel_size=(1, 1), stride=(1, 1), bias=False)
              (bn): BatchNorm2d(232, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
              (activate): ReLU(inplace=True)
            )
          )
        )
      )
      (3): ConvModule(
        (conv): Conv2d(464, 1024, kernel_size=(1, 1), stride=(1, 1), bias=False)
        (bn): BatchNorm2d(1024, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        (activate): ReLU(inplace=True)
      )
    )
  )
  (neck): GlobalAveragePooling(
    (gap): AdaptiveAvgPool2d(output_size=(1, 1))
  )
  (head): LinearClsHead(
    (loss_module): CrossEntropyLoss()
    (fc): Linear(in_features=1024, out_features=100, bias=True)
  )
  init_cfg={'type': 'Normal', 'layer': 'Linear', 'std': 0.01}
)
"""
