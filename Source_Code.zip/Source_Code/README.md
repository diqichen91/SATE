## Introduction

The source code for submission: "SATE: An Efficient Knowledge Distillation Framework with Implicit Student-Aware Teacher Ensembles".

The main implementation of the proposed framework is associated with "./mmrazor/mmrazor/model/algorithms/distill/configurable/sa_teacher_distill.py".

The configuration files are listed in "./mmrazor/configs/distill/mmcls/sanet/".

The adopted configuration files and parameters are recorded in "./config_files/".

## User Guides

# MMPretrain

- [Learn about Configs](https://mmpretrain.readthedocs.io/en/latest/user_guides/config.html)
- [Prepare Dataset](https://mmpretrain.readthedocs.io/en/latest/user_guides/dataset_prepare.html)
- [Inference with existing models](https://mmpretrain.readthedocs.io/en/latest/user_guides/inference.html)
- [Train](https://mmpretrain.readthedocs.io/en/latest/user_guides/train.html)
- [Test](https://mmpretrain.readthedocs.io/en/latest/user_guides/test.html)
- [Downstream tasks](https://mmpretrain.readthedocs.io/en/latest/user_guides/downstream.html)
- [documentation](https://mmpretrain.readthedocs.io/en/latest/)

# MMRazor

Please refer to [user guides](https://mmrazor.readthedocs.io/en/latest/user_guides/index.html) for the basic usage of MMRazor. There are also [advanced guides](https://mmrazor.readthedocs.io/en/latest/advanced_guides/index.html):

## Installation

# Runtime environment:

cuda: 11.6.2
cudnn: 8.4.1-cuda11x
miniconda3: 4.9.2
gcc: 9.3.0
python: 3.8

# Install supportive packages

pip install torch==1.13.1+cu116 torchvision==0.14.1+cu116 torchaudio==0.13.1 --extra-index-url https://download.pytorch.org/whl/cu116
pip install ninja joblib
pip install future tensorboard			

# Install MMCV

pip install -U openmim
mim install mmengine
mim install "mmcv==2.0.1"

# Install MMPretrain

cd mmpretrain # please use the package offered in this repo
mim install -e .

# Install MMRazor

cd mmrazor # please use the package offered in this repo
pip install -v -e .

## Training and Testing

There are several different ways for training and testing in different situations of hardware platforms. Please refer to the "User Guides" to more details. The overall idea is to design dataset, network architecture, algorithm, optimizer, and other elements in configuration files. 

To show the experiment settings we adopted, the configuration files are organized in the folder "./config_files/". We may adopt different hyperparameters than the default values in config files. Please refer to the Appendix for the details of the hyperparameters. In "./config_files/mmrazor/", the configuration files are listed in the format of pairs of baseline KD method and the proposed framework.

We ran experiments on a GPU cluster with slurm system. The example training and testing codes are listed below:

# Extract student model

from mmpretrain import get_model
from mmengine.runner import save_checkpoint
model_config = "${your_config_file_path}"
checkpoint_path = "${your_check_point_path}"
model = get_model(model_config, pretrained=checkpoint_path)
save_checkpoint(model.student.state_dict(), "${your_target_path}")

# Training in MMPretrain:

[ENV_VARS] bash ./tools/slurm_train.sh ${PARTITION} ${JOB_NAME} ${CONFIG_FILE} ${WORK_DIR} [PY_ARGS]

# Testing in MMPretrain:

python tools/test.py ${CONFIG_FILE} ${CHECKPOINT_FILE} [ARGS]

# Training in MMRazor:

[ENV_VARS] bash ./tools/slurm_train.sh ${PARTITION} ${JOB_NAME} ${CONFIG_FILE} ${WORK_DIR} [PY_ARGS]


# Testing in MMRazor:

python tools/test.py ${CONFIG_FILE} ${CHECKPOINT_FILE} [ARGS]
